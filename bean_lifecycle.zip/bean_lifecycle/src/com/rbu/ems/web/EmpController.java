package com.rbu.ems.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.rbu.ems.service.EmpService;

@Controller
public class EmpController {
	@Autowired
	EmpService empService;

	public EmpController() {
		System.out.println("EmpController object created");
	}

	public String post(int id, String name, String email, String address) {
		String msg = empService.create(id, name, email, address);
		return msg;
	}

}
