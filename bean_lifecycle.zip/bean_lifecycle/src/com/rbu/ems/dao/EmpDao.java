package com.rbu.ems.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class EmpDao {
//	@Autowired
//	DataSource dataSource;
	Connection con;
	@PostConstruct
	public void init() {
		System.out.println("init....");
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system","admin");
		}catch(Exception e) {}
	}
	
	
	public EmpDao() {
		System.out.println("EmpDao object created");
	}

	public String save(int id, String name, String email, String address) {
		try {
			//Connection con = dataSource.getConnection();
			Statement statement = con.createStatement();
			statement.executeUpdate(
					"insert into RBU_EMP values(" + id + ",'" + name + "','" + email + "','" + address + "')");
			statement.close();
			//con.close();
		} catch (Exception e) {
			return e.getMessage();
		}
		return "SUCCESS";
	}
	
	@PreDestroy
	public void destroy() {
		try {
			System.out.println("destroy...");
			con.close();
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	

}
