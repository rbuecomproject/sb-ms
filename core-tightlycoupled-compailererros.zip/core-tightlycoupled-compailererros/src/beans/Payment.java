package beans;

public class Payment {

}
