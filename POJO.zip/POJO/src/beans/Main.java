package beans;

public class Main {
	public static void main(String[] args) {

		Student student = new Student();
		student.setStudentName("abhishek");
		student.setStudentEmail("abhishek@gmail.com");
		student.setStudentAddress("HYD");
		System.out.println(student.getStudentName());
		System.out.println(student.getStudentEmail());
		System.out.println(student.getStudentAddress());
		System.out.println(student);// student.toString();
		Student student2 = new Student("aditya", "aditya@gmail", "HYD");
		System.out.println(student2.getStudentName());
		System.out.println(student2.getStudentEmail());
		System.out.println(student2.getStudentAddress());
		// setters and parameter constructor are for settig data into pojo class
		// getters are for reading data from your pojo class
		// we can provide setters and getters and parameter constructor and toString
		// hashcode equals vai lombok annotation

		System.out.println(student2);
	}
}
