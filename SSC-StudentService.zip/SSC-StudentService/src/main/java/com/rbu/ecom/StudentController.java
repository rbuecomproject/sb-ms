package com.rbu.ecom;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class StudentController {
	@Autowired
	RestTemplate restTemplate;
	@GetMapping("/getStudentData")
	public Student getStudentData() {
		Student student=new Student();
		student.setName("Dixit");
		
	ResponseEntity<Object> response=restTemplate.getForEntity("http://localhost:9090/getCoursesList", Object.class);
	List<Course> list=(List<Course>)response.getBody();
	student.setCourses(list);
	return student;
	}
	
}
