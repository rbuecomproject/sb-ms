package com.rbu.ecom;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CourseController {
	List<Course> list = new ArrayList<Course>();

	public CourseController() {
		Course javaCourse = new Course();
		javaCourse.setCourseId("123");
		javaCourse.setCourseName("corejava");
		javaCourse.setFee(5000);
		Course SpringCourse = new Course();
		SpringCourse.setCourseId("124");
		SpringCourse.setCourseName("Spring");
		SpringCourse.setFee(5000);
		list.add(javaCourse);
		list.add(SpringCourse);

	}
	@GetMapping("getCoursesList")
	public List<Course> getCoursesList() {
		return list;
	}
	@PostMapping("/createCourse")
	public ResponseEntity<Course> createCourse(@RequestBody Course course) {
		list.add(course);
		return new ResponseEntity<Course>(course,HttpStatus.CREATED);
	}

}
