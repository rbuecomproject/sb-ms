package com.rbu.ecom.rest;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rbu.ecom.model.Products;
import com.rbu.ecom.service.IProductService;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@AllArgsConstructor
@RequestMapping("/products")
@Slf4j
public class ProductRestController {
	final IProductService productService;
	//Logger log = LoggerFactory.getLogger(ProductRestController.class);

	@PostMapping
	public ResponseEntity<Products> createProduct(@RequestBody Products products) {
		log.info("createProduct method started..{}",products);
		return new ResponseEntity<Products>(productService.createProduct(products).get(), HttpStatus.CREATED);
	}

	@PutMapping
	public ResponseEntity<Products> updateProduct(@RequestBody Products products) {
		log.info("updateProduct method started..{}",products);
		return new ResponseEntity<Products>(productService.updateProduct(products).get(), HttpStatus.ACCEPTED);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteProduct(@PathVariable("id") Long id) {
		log.info("deleteProduct method started..{}",id);
		productService.deleteProduct(id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Products> findProductById(@PathVariable("id") Long id) {
		log.info("findProductById method started..{}",id);
		return new ResponseEntity<Products>(productService.findProductById(id).get(), HttpStatus.OK);
	}

	@GetMapping
	public ResponseEntity<List<Products>> findAllProducts() {
		log.info("findAllProducts method started..");
		return new ResponseEntity<List<Products>>(productService.findAllProducts().get(), HttpStatus.OK);
	}
}
