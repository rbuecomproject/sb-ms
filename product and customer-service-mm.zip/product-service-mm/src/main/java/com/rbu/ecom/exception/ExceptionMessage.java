package com.rbu.ecom.exception;

import java.time.LocalDate;

public class ExceptionMessage {
	private String message;
	private LocalDate currentTime;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setCurrentTime(LocalDate currentTime) {
		this.currentTime = currentTime;
	}

	public LocalDate getCurrentTime() {
		return currentTime;
	}

}
