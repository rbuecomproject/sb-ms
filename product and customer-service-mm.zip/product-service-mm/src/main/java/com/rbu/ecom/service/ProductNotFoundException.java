package com.rbu.ecom.service;

import lombok.AllArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@ToString
public class ProductNotFoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	private String message;
}
