package com.rbu.ecom.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.rbu.ecom.model.Products;
import com.rbu.ecom.repo.ProductRepo;
import com.rbu.ecom.rest.ProductRestController;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@AllArgsConstructor
@Slf4j
public class ProductService implements IProductService {
	final ProductRepo productRepo;

	@Override
	public Optional<Products> createProduct(Products product) {
		log.info("createProduct...{}",product);
		return Optional.of(productRepo.save(product));
	}

	@Override
	public Optional<Products> updateProduct(Products product) {
		Optional<Products> products = productRepo.findById(product.getProductId());
		log.info("updateProduct...{}",product);
		if (products.isPresent())
			return Optional.of(productRepo.save(product));
		throw new ProductNotFoundException("product is not available");
	}

	@Override
	public void deleteProduct(Long id) {
		Optional<Products> products = productRepo.findById(id);
		log.info("deleteProduct...{}",id);
		if (products.isPresent())
			productRepo.delete(products.get());
		throw new ProductNotFoundException("product is not available");
	}

	@Override
	public Optional<Products> findProductById(Long id) {
		Optional<Products> products = productRepo.findById(id);
		log.info("findProductById...{}",id);
		if (products.isPresent())
			return products;
		throw new ProductNotFoundException("product is not available");
	}

	@Override
	public Optional<List<Products>> findAllProducts() {
		log.info("findAllProducts...");
		return Optional.of(productRepo.findAll());
	}

}
