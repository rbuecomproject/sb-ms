package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.ems.web.EmpController;

public class IOCTest {
	public static void main(String[] args) {

		ApplicationContext ap = new ClassPathXmlApplicationContext("resources/spring.xml");

		EmpController emp = ap.getBean(EmpController.class);
		String msg = emp.post(2, "dixit", "dixit@gmail.com", "HYD");
		System.out.println(msg);

	}
}
