package com.rbu.ems.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import org.springframework.stereotype.Repository;

@Repository
public class EmpDao {
	public EmpDao() {
	System.out.println("EmpDao object created");
	}

	public String save(int id, String name, String email, String address) {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			Statement statement = con.createStatement();
			statement.executeUpdate(
					"insert into RBU_EMP values(" + id + ",'" + name + "','" + email + "','" + address + "')");
			statement.close();
			con.close();
		} catch (Exception e) {
			return e.getMessage();
		}
		return "SUCCESS";
	}

}
