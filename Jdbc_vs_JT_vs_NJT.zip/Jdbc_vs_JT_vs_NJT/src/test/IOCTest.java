package test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.ems.dao.Employee;
import com.rbu.ems.web.EmpController;

public class IOCTest {
	public static void main(String[] args) {

		ApplicationContext ap = new ClassPathXmlApplicationContext("resources/spring.xml");

		EmpController emp = ap.getBean(EmpController.class);
//		emp.post(3, "naveen", "naveen@gmail.com", "HYD");
//		String msg = emp.put(2, "praveenHS", "praveen@ymail.com", "BNG");
//		System.out.println(msg);
//		String msg =emp.delete(1);
//		System.out.println(msg);
//		Employee employe= emp.getbyId(2);
//		System.out.println(employe);
		List<Employee> list=emp.getAll();
		list.forEach(em->System.out.println(em));
	}
}
