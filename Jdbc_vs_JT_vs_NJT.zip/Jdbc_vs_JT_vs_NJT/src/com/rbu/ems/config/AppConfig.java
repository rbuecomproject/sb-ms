package com.rbu.ems.config;

import java.beans.PropertyVetoException;

import javax.sql.DataSource;

import org.apache.tomcat.dbcp.dbcp.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class AppConfig {

	public AppConfig() {
		System.out.println("AppConfig object created..");
	}

	@Bean(name = "bds")
	public DataSource createConnectionPool() {
		System.out.println("BDS:createConnectionPool....");
		BasicDataSource bds = new BasicDataSource();// at a time it can hold N number of connections
		bds.setDriverClassName("oracle.jdbc.OracleDriver");
		bds.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		bds.setUsername("system");
		bds.setPassword("admin");
		bds.setMaxActive(1);
		bds.setMaxWait(2000);
		return bds;
	}

	@Bean(name = "c3p0")
	public DataSource createConnectionPoolwithC3P0() throws PropertyVetoException {
		System.out.println("C3P0:createConnectionPool....");
		ComboPooledDataSource cp = new ComboPooledDataSource();// at a time it can hold N number of connections
		cp.setDriverClass("oracle.jdbc.OracleDriver");
		cp.setJdbcUrl("jdbc:oracle:thin:@localhost:1521:xe");
		cp.setUser("system");
		cp.setPassword("admin");
		cp.setMaxPoolSize(1);
		cp.setMaxIdleTime(2000);
		return cp;
	}

	@Bean
	public JdbcTemplate createJt() throws PropertyVetoException {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(createConnectionPoolwithC3P0());
		return jdbcTemplate;
	}

//	@Bean(name = "hikari")
//	public DataSource createConnectionPoolwithHikari() throws PropertyVetoException {
//		System.out.println("Hikari:createConnectionPool....");
//		HikariConfig config = new HikariConfig();
//		config.setDriverClassName("oracle.jdbc.driver.OracleDriver");
//		config.setJdbcUrl("jdbc:oracle:thin:@localhost:1521:xe");
//		config.setUsername("system");
//		config.setPassword("admin");
//		config.setMaximumPoolSize(10);
//		return new HikariDataSource(config);
//	}

}
