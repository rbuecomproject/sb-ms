package com.rbu.ems.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class EmpDaoJt {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public EmpDaoJt() {
		System.out.println("EmpDao object created");
	}

	// 100Dao 5crud(1-lines) methods 2500 vs 500
	public String save(int id, String name, String email, String address) {
		jdbcTemplate.update("insert into RBU_EMP values(" + id + ",'" + name + "','" + email + "','" + address + "')");
		return "SUCCESS";
	}

	public String update(int id, String name, String email, String address) {
		jdbcTemplate.update("update RBU_EMP set name='" + name + "',email='" + email + "',address='" + address
				+ "' where id=" + id + "");
		return "SUCCESS";
	}

	public String delete(int id) {
		jdbcTemplate.update("delete RBU_EMP where id=" + id);
		return "SUCCESS";
	}

	public Employee findEmp(int id) {
		Employee emp = jdbcTemplate.queryForObject("select * from RBU_EMP where id=" + id, new RS_toEMP_RMP());
		return emp;
	}

	public List<Employee> findAllEmp() {
		List<Map<String, Object>> list = jdbcTemplate.queryForList("select * from RBU_EMP");
		List<Employee> empList = new ArrayList<Employee>();
		for (Map map : list) {
			Employee emp = new Employee();
			BigDecimal id = (BigDecimal) map.get("ID");
			String name = (String) map.get("NAME");
			String email = (String) map.get("EMAIL");
			String address = (String) map.get("ADDRESS");
			emp.setId(id.intValue());
			emp.setName(name);
			emp.setEmail(email);
			emp.setAddress(address);
			empList.add(emp);
		}
		return empList;

	}

}
