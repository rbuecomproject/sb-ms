package com.rbu.ems.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository
public class EmpDao {
	@Qualifier("c3p0")
	@Autowired
	DataSource dataSource;

	public EmpDao() {
		System.out.println("EmpDao object created");
	}
	//100Dao 5crud(1-lines) methods 2500 vs 500

	public String save(int id, String name, String email, String address) {
		try {
			Connection con = dataSource.getConnection();
			Statement statement = con.createStatement();
			statement.executeUpdate(
					"insert into RBU_EMP values(" + id + ",'" + name + "','" + email + "','" + address + "')");
			statement.close();
			con.close();
		} catch (Exception e) {
			return e.getMessage();
		}
		return "SUCCESS";
	}
//	public String saveStd(int id, String name, String email, String address) {
//		try {
//			Connection con = dataSource.getConnection();
//			Statement statement = con.createStatement();
//			statement.executeUpdate(
//					"insert into RBU_STD values(" + id + ",'" + name + "','" + email + "','" + address + "')");
//			statement.close();
//			con.close();
//		} catch (Exception e) {
//			return e.getMessage();
//		}
//		return "SUCCESS";
//	}
//	public String savePrd(int id, String name, String email, String address) {
//		try {
//			Connection con = dataSource.getConnection();
//			Statement statement = con.createStatement();
//			statement.executeUpdate(
//					"insert into RBU_PRD values(" + id + ",'" + name + "','" + email + "','" + address + "')");
//			statement.close();
//			con.close();
//		} catch (Exception e) {
//			return e.getMessage();
//		}
//		return "SUCCESS";
//	}
	
	public String savejdbc(int id, String name, String email, String address) {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "admin");
			Statement statement = con.createStatement();
			statement.executeUpdate(
					"insert into RBU_EMP values(" + id + ",'" + name + "','" + email + "','" + address + "')");
			statement.close();
			con.close();
		} catch (Exception e) {
			return e.getMessage();
		}
		return "SUCCESS";
	}

}
